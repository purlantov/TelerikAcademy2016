﻿using System;

namespace Exceptions_Homework
{
    public abstract class Exam
    {
        public abstract ExamResult Check();
    }
}