﻿namespace Academy.Models.Enums
{
    public enum Track
    {
        Frontend = 0,
        Dev = 1,
        None = 2
    }
}
