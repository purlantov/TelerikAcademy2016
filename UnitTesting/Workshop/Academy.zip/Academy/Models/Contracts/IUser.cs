﻿namespace Academy.Models
{
    public interface IUser
    {
        string Username { get; set; }
    }
}
